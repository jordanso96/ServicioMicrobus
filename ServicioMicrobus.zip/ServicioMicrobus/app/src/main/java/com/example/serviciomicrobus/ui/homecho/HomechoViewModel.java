package com.example.serviciomicrobus.ui.homecho;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class HomechoViewModel extends ViewModel {

    private MutableLiveData<String> mText;

    public HomechoViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("Bienvenido Chofer de Microbus");
    }

    public LiveData<String> getText() {
        return mText;
    }
}