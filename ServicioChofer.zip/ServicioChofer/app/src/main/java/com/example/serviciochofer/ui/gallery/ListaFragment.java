package com.example.serviciochofer.ui.gallery;

        import android.content.Intent;
        import android.os.Bundle;
        import android.telephony.SmsManager;
        import android.view.LayoutInflater;
        import android.view.View;
        import android.view.ViewGroup;
        import android.widget.AdapterView;
        import android.widget.ArrayAdapter;
        import android.widget.ListView;
        import android.widget.TextView;
        import android.widget.Toast;

        import androidx.annotation.Nullable;
        import androidx.annotation.NonNull;
        import androidx.fragment.app.Fragment;
        import androidx.lifecycle.Observer;
        import androidx.lifecycle.ViewModelProviders;

        import com.example.serviciochofer.R;

        import java.io.IOException;
        import java.net.UnknownHostException;
        import java.util.ArrayList;

public class ListaFragment extends Fragment {

    private ListaViewModel listaViewModel;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        listaViewModel =
                ViewModelProviders.of(this).get(ListaViewModel.class);
        View root = inflater.inflate(R.layout.fragment_lista, container, false);

        ((TextView) root.findViewById(R.id.txtStreetAddr)).setText(
                "Lista de Estudiantes");

        ListView phoneListView =((ListView) root.findViewById(R.id.list));

        ArrayList<String> phNumbers = new ArrayList<String>();
        phNumbers.add("Pedrito");
        phNumbers.add("Carlitos");
        phNumbers.add("Leito");
        phNumbers.add("Davidcito");

        ArrayAdapter<String> arrayAdapter =
                new ArrayAdapter<String>(getActivity(),android.R.layout.simple_list_item_1, phNumbers);
        // Set The Adapter
        phoneListView.setAdapter(arrayAdapter);


        phoneListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {

                //Intent myIntent = new Intent(getActivity(), NextActivity.class);
                //startActivity(myIntent);

                //ENVIAR MENSAJE

                try{

                    SmsManager smgr = SmsManager.getDefault();
                    smgr.sendTextMessage("60242784",null,"SU hijo ha llegado",null,null);



                }  catch (Exception e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
                }

                Toast.makeText(getActivity().getApplicationContext(), "Mensaje enviado", Toast.LENGTH_LONG).show();


            }
        });


        return root;
    }



}