package com.example.serviciochofer;

        import java.io.IOException;
        import java.io.UnsupportedEncodingException;
        import java.net.URLDecoder;
        import java.util.Collections;
        import java.util.HashMap;
        import java.util.HashSet;
        import java.util.Map;
        import java.util.Set;



public class SocketServer {

}