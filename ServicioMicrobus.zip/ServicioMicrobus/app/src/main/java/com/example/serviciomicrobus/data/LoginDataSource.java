package com.example.serviciomicrobus.data;

import com.example.serviciomicrobus.data.model.LoggedInUser;

import java.io.IOException;

/**
 * Class that handles authentication w/ login credentials and retrieves user information.
 */
public class LoginDataSource {

    public Result<LoggedInUser> login(String username, String password) {


        try {

            if (username.equals("padre")){
                // TODO: handle loggedInUser authentication
                LoggedInUser padre =
                        new LoggedInUser(
                                java.util.UUID.randomUUID().toString(),
                                "Carlos Cueva", "padre");
                return new Result.Success<>(padre);

            } else if (username.equals("chofer")){
                // TODO: handle loggedInUser authentication
                LoggedInUser chofer =
                        new LoggedInUser(
                                java.util.UUID.randomUUID().toString(),
                                "Chofer Valeria", "chofer");
                return new Result.Success<>(chofer);


            } else {

                LoggedInUser fakeUser =
                        new LoggedInUser(
                                java.util.UUID.randomUUID().toString(),
                                "None", "none");
                return new Result.Success<>(fakeUser);

            }


        } catch (Exception e) {
            return new Result.Error(new IOException("Error logging in", e));

        }


    }

    public void logout() {
        // TODO: revoke authentication
    }
}
