        package com.example.serviciomicrobus.ui.Mapa;

        import android.os.Bundle;
        import android.os.Handler;
        import android.os.Message;
        import android.view.LayoutInflater;
        import android.view.View;
        import android.view.ViewGroup;
        import android.widget.AdapterView;
        import android.widget.Button;
        import android.widget.Toast;

        import androidx.annotation.NonNull;
        import androidx.fragment.app.Fragment;
        import androidx.fragment.app.FragmentActivity;
        import androidx.lifecycle.ViewModelProviders;

        import com.example.serviciomicrobus.R;
        import com.google.android.gms.maps.CameraUpdateFactory;
        import com.google.android.gms.maps.GoogleMap;
        import com.google.android.gms.maps.OnMapReadyCallback;
        import com.google.android.gms.maps.SupportMapFragment;
        import com.google.android.gms.maps.model.CameraPosition;
        import com.google.android.gms.maps.model.LatLng;
        import com.google.android.gms.maps.model.MarkerOptions;

        import java.io.BufferedReader;
        import java.io.IOException;
        import java.io.InputStreamReader;
        import java.io.ObjectInputStream;
        import java.io.ObjectOutputStream;
        import java.net.InetAddress;
        import java.net.Socket;
        import java.net.UnknownHostException;

        public class MapaFragment extends Fragment {
            private Button btn1, btn2;
            private GoogleMap mMap;
            private static final String HOST = "10.0.2.2";
            private static final int PORT = 8080;
            private String line;

            private MapaViewModel maViewModel;

            public View onCreateView(@NonNull LayoutInflater inflater,
                                     ViewGroup container, Bundle savedInstanceState) {
                maViewModel =
                        ViewModelProviders.of(this).get(MapaViewModel.class);
                View root = inflater.inflate(R.layout.fragment_mapa, container, false);

                Button button = (Button) root.findViewById(R.id.btn1);
                button.setOnClickListener(new View.OnClickListener()
                {
                    @Override
                    public void onClick(View v)
                    {

                        //new Thread() {
                        //    @Override
                        //    public void run() {
                        //        try {
                                    // Create Socket instance
                        //            Socket socket = new Socket(HOST, PORT);
                        //            // Get input buffer
                        //            BufferedReader br = new BufferedReader(
                        //                    new InputStreamReader(socket.getInputStream()));
                        //            line = br.readLine();

                        //            br.close();
                        //        } catch (UnknownHostException e) {
                        //            // TODO Auto-generated catch block
                         //           e.printStackTrace();
                         //       } catch (IOException e) {
                         //           // TODO Auto-generated catch block
                         //           e.printStackTrace();
                         //       }
                          //      handler.sendEmptyMessage(0);
                         //   }
                        //}.start();

                        SupportMapFragment mapFragment = (SupportMapFragment) getChildFragmentManager().findFragmentById(R.id.frg);  //use SuppoprtMapFragment for using in fragment instead of activity  MapFragment = activity   SupportMapFragment = fragment
                        mapFragment.getMapAsync(new OnMapReadyCallback() {
                            @Override
                            public void onMapReady(GoogleMap mMap) {
                                mMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);

                                mMap.clear(); //clear old markers

                                // Cargar Ubicación
                                LatLng sydney = new LatLng(9.94973178447, -84.1302345289);
                                mMap.addMarker(new MarkerOptions().position(sydney).title("Microbus"));
                                mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(sydney, 15));
                            }
                        });


                    }


                });


                return root;
            }

            // Define Handler object
            private Handler handler = new Handler() {
                @Override
                // When there is message, execute this method
                public void handleMessage(Message msg) {
                    super.handleMessage(msg);
                    // Update UI

                    Toast.makeText(getActivity().getApplicationContext(), line, Toast.LENGTH_LONG).show();


                }
            };




            public void onMapReady(GoogleMap googleMap) {
                mMap = googleMap;

                 //Add a marker in Sydney and move the camera
                LatLng sydney = new LatLng(-34, 151);
                mMap.addMarker(new MarkerOptions().position(sydney).title("Marker in Sydney"));
                mMap.moveCamera(CameraUpdateFactory.newLatLng(sydney));
            }

        }